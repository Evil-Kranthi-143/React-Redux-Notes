import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { addNote } from '../Redux/Action';
import { useNavigate } from 'react-router-dom';
import AllNotes from './AllNotes';



export default function NotesForm() {

const Navigate = useNavigate()

  let [title, setTitle] = useState('');
  let [content, setContent] = useState('')

  const dispatch = useDispatch();


  function handleSubmission(e) {
    e.preventDefault();
    dispatch(addNote(title,content));
    setTitle("");
    setContent("");
    Navigate('/AllNotes')
  }
  console.log(title,content)

  return (
    <div className='mainform'>
        <h1> React Redux Note </h1>
        <br/>
        <form onSubmit={handleSubmission}>
            <h2>Title</h2>
            <input type='text' name='title' value={title} placeholder='Enter Title' onChange={(e)=>setTitle(e.target.value)} required/> 
            <br/><br/>
            <h2>Content</h2> 
            <textarea type='text' name='content' value={content} placeholder='Enter Content' onChange = {(e)=> setContent(e.target.value)} required className='form-control' rows={6}></textarea> <br/>
            <br/>
            <br/>
            <button class="button-73"> Add My Note </button>
            <br/><br/>
            <button
              className="button-73"
              id="notebtn"
              onClick={() => Navigate("/AllNotes")}>
              Notelist
            </button>
        </form>
        <br/>
        <AllNotes/>
    </div>
  )
}
