import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { removeNote } from '../Redux/Action'
import { useNavigate } from 'react-router-dom';


export default function AllNotes() {

    const mynotes = useSelector((state) => state.notes)

    const dispatch = useDispatch();
    const Navigate = useNavigate();

    return (
        <>

            <header>
                <nav class="navbar">
                    <div class="container justify-content-center">
                        <h1 class="navbar-brand mb-0 h1 fs-2">React Notelist</h1>
                    </div>
                </nav>
            </header>
            <br />
            <button className="button-73" id='home' onClick={() => Navigate('/')}> Home Page </button>
            <br /><br />
            <div className='d-flex'>
                {
                    mynotes.map((note, index) => {
                        return (
                            <>
                                <br />
                                <br />
                                <div className="card g-col-4" style={{ width: "20rem", }}>
                                    <div className="card-body p-5">
                                        <h3 className="card-title fs-3">{note.title}</h3>
                                        <p className="card-text fs-5">{note.content}</p>
                                        <button className="btn btn-danger" onClick={() => dispatch(removeNote(index))}>Delete</button>
                                        <br /><br />
                                        <button type="button" class="btn btn-primary" onClick={() => Navigate('/notes', { state: { id: index } })} data-toggle="modal" data-target="#exampleModal">
                                            Update
                                        </button>
                                        <br />
                                    </div>
                                </div >


                            </>

                        )

                    })
                }

            </div >
            <br /> <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

        </>

    )

}