import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import AllNotes from './Components/AllNotes';
import NotesForm from './Components/NotesForm';
import UpdateNote from './Components/UpdateNote';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<NotesForm />} />
          <Route path='/AllNotes' element={<AllNotes />} />
          <Route path='/Notes' element={<UpdateNote />} />
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
