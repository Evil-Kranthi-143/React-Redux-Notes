import React, { useEffect } from 'react'
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { updateNote } from '../Redux/Action';
import { useLocation, useNavigate } from 'react-router-dom';


export default function UpdateNote() {

  let [title, setTitle] = useState('');
  let [content, setContent] = useState('');
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const location = useLocation();
  const index = location.state.id;
  const notes = useSelector((state) => state.notes);

  useEffect(() => {
    setTitle(notes[index].title)
    setContent(notes[index].content)
  },
  {index,notes})






  const handleUpdate = (e) => {
    e.preventDefault();
    dispatch(updateNote(index, title, content))
    Navigate("/AllNotes")
  }

  return (
    <>
      <br />
      <header>
        <nav class="navbar">
          <div class="container justify-content-center">
            <span class="navbar-brand mb-0 h1 fs-3">React Note Update</span>
          </div>
        </nav>
      </header>

      <br/>
      <button className="button-73" id='home' onClick={() => Navigate("/")}><span>Home Page</span> </button>
      <button className='button-73' onClick={() => Navigate('/AllNotes')}><span>Notelist</span></button>
      <br /><br />

      <form onSubmit={handleUpdate}>
        <div className="mx-auto " style={{ width: "75%" }}>
          <div className="card-body p-4 g-col-12">
            <br />
            <br />
            <h2>Title</h2>
            <input type='text' name='title' value={title} placeholder='Enter Title' onChange={(e) => setTitle(e.target.value)} required />
            <br /><br />
            <h2>Content</h2>
            <textarea type='text' name='content' value={content} placeholder='Enter content' onChange={(e) => setContent(e.target.value)} required className='form-control' rows={6}></textarea>
            <br />
            <br />
            <button className='button-73'> Save My Note </button>
          </div>
        </div>
      </form>

    </>

  )
}
